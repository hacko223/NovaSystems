--drag this script to ServerScriptService

local WhitelistModule = require(game.ServerScriptService:WaitForChild("WhitelistModule"))

local KICK_MESSAGE = "No estás en la whitelist para unirte a este juego."

game.Players.PlayerAdded:Connect(function(player)
    if not WhitelistModule.IsWhitelisted(player) then
        player:Kick(KICK_MESSAGE)
        return
    end
    print("[Whitelist] " .. player.Name .. " entró al servidor.")
end)

game.Players.PlayerRemoving:Connect(function(player)
    print("[Whitelist] " .. player.Name .. " salió del servidor.")
end)

--creditos a https://create.roblox.com/store/asset/17314339807/Whitelist-Module 
--mejore esta version, pero el script inicial lo hizo: https://www.roblox.com/es/users/323134007/profile