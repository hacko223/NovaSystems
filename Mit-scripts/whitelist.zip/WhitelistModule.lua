--drag this script to ServerScriptService
--change the user id

local WhitelistModule = {}

local whitelist = {
    [123456789] = true, -- Reemplaza con tu UserId
    [987654321] = true,
}

function WhitelistModule.IsWhitelisted(player)
    return whitelist[player.UserId] or false
end

return WhitelistModule
--creditos a https://create.roblox.com/store/asset/17314339807/Whitelist-Module 
--mejore esta version, pero el script inicial lo hizo: https://www.roblox.com/es/users/323134007/profile